package day6;

public class Ques60ConversionOfBinaryAndDecimal {
    public static void main(String[] args){
        int decimal = 15;
        int rem;
        String binary = " ";
        while(decimal>0){
            rem = decimal % 2;
            binary = rem + binary;
            decimal = decimal/2;
        }
        System.out.println("Decimal to binary:"+binary);

        int bin = 10110;
        double dec = 0, i = 0;
        while(bin>0){
            rem = bin%10;
            dec = dec + (rem*Math.pow(2,i));
            bin = bin/10;
            i++;
        }
        System.out.println("binary to decimal:"+dec);
    }
}
