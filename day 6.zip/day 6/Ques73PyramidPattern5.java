package day6;

public class Ques73PyramidPattern5 {
    public static void main(String[] args) {
        int row = 9, k;
        int temp = row;
        for (int i = 1; i <= row; i++) {
            System.out.println();
            for (int j = row; j > i; j--) {
                System.out.print("  ");
            }
            for (k = temp; k <= row; k++) {
                System.out.print(k + " ");
            }
            for (int l = row - 1; l >= temp; l--) {
                System.out.print(l + " ");
            }
            temp--;
        }
    }
}
