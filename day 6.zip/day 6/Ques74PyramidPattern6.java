package day6;

public class Ques74PyramidPattern6 {
    public static void main(String[] args) {
        int row = 9;
        int temp = row;
        for (int i = 1; i <= row; i++) {
            System.out.println();
            for (int k = 1; k < i; k++) {
                System.out.print(" ");
            }
            for (int j = 0; j <= row - i; j++) {
                System.out.print(temp + " ");
            }
            temp--;
        }
    }
}
