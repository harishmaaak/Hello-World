package day6;

import java.util.Scanner;

public class Ques64PowerRecursion {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter base number: ");
        int base = in.nextInt();
        System.out.print("Enter power number(positive integer): ");
        int power = in.nextInt();
        int result = calculatePower(base,power);
        System.out.print(base + " ^ "+power+" = "+result);
    }

    private static int calculatePower(int base, int power) {
        if (power != 0)
            return (base * calculatePower(base, power-1));
        else
            return 1;
    }
}
