package day6;

public class Ques72PyramidPattern4 {
    public static void main(String[] args){
        int row = 9,k;
        for(int i=1;i<=row;i++){
            System.out.println();
            for(int j=row;j>i;j--){
                System.out.print("  ");
            }
            for( k=1;k<=i;k++){
                System.out.print(k+" ");
            }
            for(int l=k-2;l>0;l--){
                System.out.print(l+" ");
            }
        }
    }
}
