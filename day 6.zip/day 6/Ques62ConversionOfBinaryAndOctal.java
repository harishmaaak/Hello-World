package day6;

public class Ques62ConversionOfBinaryAndOctal {
    public static void main(String[] args) {
        int octal = 67;
        int decimalNumber = 0, i = 0;
        long binaryNumber = 0;

        while (octal != 0) {
            decimalNumber += (octal % 10) * Math.pow(8, i);
            ++i;
            octal /= 10;
        }

        i = 1;

        while (decimalNumber != 0) {
            binaryNumber += (decimalNumber % 2) * i;
            decimalNumber /= 2;
            i *= 10;
        }
        System.out.println("octal to binary : " + binaryNumber);

        long binary = 110111;
        int octalNumber = 0, decimal = 0,j = 0;

        while (binary != 0) {
            decimal += (binary % 10) * Math.pow(2, j);
            ++j;
            binary /= 10;
        }

        j = 1;

        while (decimal != 0) {
            octalNumber += (decimal % 8) * j;
            decimal /= 8;
            j *= 10;
        }
        System.out.println("binary to octal : "+ octalNumber);
    }
}

