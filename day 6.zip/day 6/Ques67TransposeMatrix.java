package day6;

public class Ques67TransposeMatrix {
    public static void main(String[] args) {
        int[][] actualMatrix = {{3, 5, 6}, {1, 4, 7}, {4, 9, 6}};
        int[][] transposeMatrix = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                transposeMatrix[i][j] = actualMatrix[j][i];
            }
        }
        System.out.println("The actual matrix is :");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(actualMatrix[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("The transpose matrix is :");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(transposeMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}
