package day6;

public class Ques69PyramidPattern1 {
    public static void main(String[] args){
        int row = 9;
        for(int i=1;i<=row;i++){
            System.out.println();
            for(int j=row;j>=i;j--){
                System.out.print(" ");
            }
            for(int k=1;k<=i;k++){
                System.out.print(i+" ");
            }

        }
    }
}
