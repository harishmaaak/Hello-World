package day6;

public class Ques61ConversionOfOctalAndDecimal {
    public static void main(String[] args){
        int decimal = 153;
        int rem;
        String octal= " ";
        while(decimal>0){
            rem = decimal % 8;
            octal = rem + octal;
            decimal =decimal/8;
        }
        System.out.println("Decimal to octal :"+octal);

        int oct = 231;
        double dec = 0, i = 0;
        while(oct>0){
            rem = oct%10;
            dec = dec + (rem*Math.pow(8,i));
            oct = oct/10;
            i++;
        }
        System.out.println("octal to decimal:"+dec);
    }
}


