package schoolsPractice;

public class Datatype {
    public static void main(String[] args){
        long num = 9876543210L;
        System.out.println(num);
    }
}
