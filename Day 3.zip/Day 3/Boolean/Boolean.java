package schoolsPractice;

public class Boolean {
    public static void main(String[] args){
        System.out.println(true);
        System.out.println(false);
        System.out.println(true&true);
        System.out.println(true&false);
    }
}
