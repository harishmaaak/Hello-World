package schoolsPractice;

public class SameDifferent {
    public static void main(String[] args){
        int n =6;
        long d =6L;
        if (n==d){
            System.out.println("same");
        }else
        {
            System.out.println("Different");
        }
    }
}
