package schoolsPractice;

public class IntNumber {
    public static void main(String[] args){
        float floatNumber = 150.9f;
        int intNumber =(int) floatNumber;
        System.out.println(intNumber);
    }
}
