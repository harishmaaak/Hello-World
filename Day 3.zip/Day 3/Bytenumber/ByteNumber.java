package schoolsPractice;

public class ByteNumber {
    public static void main(String[] args){
        short shortNumber = 150;
        byte byteNumber =(byte) shortNumber;
        System.out.println(byteNumber);
    }
}
