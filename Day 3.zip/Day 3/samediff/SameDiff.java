package schoolsPractice;

public class SameDiff {
    public static void main(String[] args){
        float e = 6.02f;
        double d =  6.02d;
        if(e==d){
            System.out.println("same");
        }else
        {
            System.out.println("Different");
        }
    }
}
