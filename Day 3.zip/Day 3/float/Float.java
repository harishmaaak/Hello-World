package schoolsPractice;

public class Float {
    public static void main(String[] args){
        float f = 7.50F;
        System.out.println(f);
    }
}
