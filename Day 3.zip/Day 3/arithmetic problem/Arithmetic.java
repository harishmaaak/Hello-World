package schoolsPractice;

public class Arithmetic {
    public static void main(String[] args){
            System.out.println(7+7);
            System.out.println(7+7.0);
        System.out.println(7+'7');
    }
}
