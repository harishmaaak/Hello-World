package inheritance;

import harishmaa.String;
import inheritance.BabyDog;

public class TestCase2 {
    public static void main(String[] args){
        BabyDog bd = new BabyDog();
        bd.weep();
        bd.bark();
        bd.eat();
    }
}
