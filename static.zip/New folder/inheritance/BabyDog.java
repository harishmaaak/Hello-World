package inheritance;

public class BabyDog extends Dog {
    void weep(){
        System.out.println("weeping");
    }
}
