package harishmaa;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayInput {
    public static void main(String[] args) {
        System.out.print("Enter the array size: ");
        Scanner scan = new Scanner(System.in);
        int n =scan.nextInt();
         int[] arr= new int[n];
        System.out.print("The array input is: ");
         for(int i=0;i< arr.length;i++){
             arr[i]=scan.nextInt();
         }
    System.out.println("The given array input="+" "+ Arrays.toString(arr));
    }
}
