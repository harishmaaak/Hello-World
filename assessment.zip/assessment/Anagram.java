import java.util.*;

public class Anagram {
    public static void main(String[] args) {
        String s1 = "Listen";
        String s2 = "Silent";
        String str1 = s1.replaceAll("//s", "");
        String str2 = s2.replaceAll("//s", "");
        boolean input = true;

        if (str1.length() != str2.length()) {
            input = false;
            
        } else {
            char[] string1 = str1.toLowerCase().toCharArray();
            char[] string2 = str2.toLowerCase().toCharArray();
            Arrays.sort(string1);
            Arrays.sort(string2);

            if (Arrays.equals(string1, string2)) {
                System.out.println("The given string is anagram");
            } else {
                System.out.println("The given string is not anagram");
            }
        }

    }
}
