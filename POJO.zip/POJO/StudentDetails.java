import java.util.*;

public class StudentDetails {
	ArrayList<Student> arr = new ArrayList<Student>();
    Scanner sc = new Scanner(System.in);
	void enterDetails() {
		Student obj = new Student();
		System.out.println("Enter the name: ");
		String name = sc.nextLine();
		obj.setName(name);
		System.out.println("Enter the Id: ");
		int id = sc.nextInt();
		sc.nextLine();
		obj.setId(id);
		System.out.println("Enter the gender: ");
		String gender = sc.nextLine();
		obj.setGender(gender);
		arr.add(obj);
	}

	void showDetails() {
		for (Student e : arr) {
			System.out.println("Student ID : " + e.getId());
			System.out.println("Student Name : " + e.getName());
			System.out.println("Student Gender : " + e.getGender());
			System.out.println();

		}
	}

	void showSpecificDetail() {
		System.out.println("Enter any one of ID: ");
		int a = sc.nextInt();
		for (Student em : arr) {
			if (a == em.getId()) {
				System.out.println("Student ID : " + em.getId());
				System.out.println("Student Name : " + em.getName());
				System.out.println("Student Gender : " + em.getGender());

			}
		}
	}

	void gatherDetails() {
		Scanner sc = new Scanner(System.in);
		StudentDetails obj1 = new StudentDetails();
		int choose;
		do {
			System.out.println(
					"1.Enter Details \n 2.view the specific student detail \n 3.view the entire Student details \n 0.Exit");
			choose = sc.nextInt();
			switch (choose) {
				case 1:
					obj1.enterDetails();
					break;
				case 2:
					obj1.showDetails();
					break;
				case 3:
					obj1.showSpecificDetail();
					break;
				case 0:
					System.out.println("Exit");
					break;
				default:
					System.out.println("Invalid option");
			}
		} while (choose != 0);
	}

	public static void main(String[] args) {
		StudentDetails obj = new StudentDetails();
		obj.gatherDetails();

	}

}
